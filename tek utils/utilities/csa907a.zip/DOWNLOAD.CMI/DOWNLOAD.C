/* Connect clock and data out (Tx) to the clock and data in (Rx);  Addresses
   should be at the default (14,15);  Use a National Instrument GPIB card with
   the GPIB.COM file;  
*/

#include <ctype.h>
#include <math.h>
#include <memory.h>
#include <stddef.h>
#include <dos.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include "fdib.h"
#include "fdlid2.h"

#define gpib_PC  0

#define ERR     (1<<15) /* Error detected                  */
#define TIMO    (1<<14) /* Timeout                         */

#define ROWA 10
#define COLA 10
#define ROWB 10
#define COLB 10

/* Status variables declared public by *cib*.obj.          */
extern  int     ibsta;  /* status word                     */
extern  int     iberr;  /* GPIB error code                 */
extern  int     ibcnt;  /* number of bytes sent            */

char unsigned data[32768];
char unsigned tmpdata[32768];
long datalen=0;

int CSA907AR=14;
int CSA907AT=15;
int gpib_Rx=14;
int gpib_Tx=15;
int gpib_device, bd;
int color=15+16*1;
int bad_color=14+16*4;
int index=0;
int MAXTIME=0;

int inputi=6, outputi=6;
char output[7][180];
char  input[7][180];
char options[100];

extern char *getonemore(int number, int dspmode);


/********************************************************************/

char *getonemore(int number, int dspmode)
{
	int i,value;
	char *temp="       ";

	if (dspmode==2)
	{
		temp[0]=32;
		temp[1]=0;
		if (number<=31)
		{
			for(i=4; i>=0; i--)
			{
				value=1<<i;
				if (number>=value){
					strcat(temp,"1");
					number-=value;
				}
				else
					strcat(temp,"0");
			}
		}
		else
			strcpy(temp," error");
		return(temp);
	}
	else if (dspmode==8)
	{
		sprintf(temp,"  %2.2o  ",number);
		return(temp);
	}
	else if (dspmode==10)
	{
		sprintf(temp,"  %2.2d  ",number);
		return(temp);
	}
	else if (dspmode==16)
	{
		sprintf(temp,"  %2.2X  ",number);
		return(temp);
	}
	else if (dspmode==32)
	{
		sprintf(temp,"  %3.3o ",number);
		return(temp);
	}
	else return(" error");
}

/*****************************************************************************
 *****************************************************************************/

int strtest(msg1,msg2)

char msg1[],msg2[];
{
	int l1,l2,found,i,j,k,m;

	l1=strlen(msg1); l2=strlen(msg2);
	for (i=0,j=0,found=-1; i<l1 && j<l2 && found<0; i++)
	{
		if (msg1[i]==msg2[0])
		{
			for(k=i,j=0;k<l1 && j<l2 && msg1[k]==msg2[j];k++,j++);
			if (j==l2) found=i;
		}
	}
	return(found);
}

/*****************************************************************************
 *****************************************************************************/

void wait_here(int timeout /* in tens of milli-seconds */)
{

	int start,  delta;
	union REGS inregs, outregs;

	inregs.h.ah = 0x2c;
	intdos(&inregs,&outregs);
	start = outregs.h.dh * 100 + outregs.h.dl; /* start time */
	delta = 0;
	while (delta < timeout)
	{
	    intdos(&inregs,&outregs);             /* get current time */
	    delta = outregs.h.dh * 100 + outregs.h.dl - start;
	    if (delta < 0)
		{
		start = start - 60 * 100;
		delta = 60 * 100 + delta;
		}
	}
}

/*****************************************************************************
 *****************************************************************************/

void ibwrtbd(bd,msg,cnt)
int bd,cnt;
char msg[];
{
    char cmd[2];
    char msg2[100];
    int i,j;

    cmd[0]=32+gpib_device;
    cmd[1]=64+gpib_PC;
    ibcmd(bd,"?_",2);    /* set GPIB to UNL, UNT */
    ibcmd(bd,cmd,2);
    ibwrt(bd, msg,cnt);

    ++outputi;
    outputi %= 7;
    sprintf(msg2,"                                                          ");
    sprintf(output[outputi],"OUT%d,%d:>%s<%s",gpib_device,ibsta&TIMO,msg,msg2);
    j=outputi;
    dso(output[j],38+13,7+1,2,color);
    for(i=1; i<7; i++)
    {
	if (--j==-1) j=6;
	dso(output[j],38+13,7+1-i,2,color-8);
    }
    mvcrsr( 8,7);
}

/*****************************************************************************
 *****************************************************************************/

void ibrdbd(bd,msg,cnt)
int bd,cnt;
char msg[];
{
    char cmd[2];
    char msg2[100], msg3[100];
    int i,j;
    
    cmd[0]=32+gpib_PC;
    cmd[1]=64+gpib_device;
    ibcmd(bd,"?_",2);    /* set GPIB to UNL, UNT */
    ibcmd(bd,cmd,2);
    ibrd(bd, msg,cnt);

    msg[ibcnt]=0;
    ++inputi;
    inputi %= 7;
    sprintf(msg2,"                                                          ");
    sprintf(input[inputi],"IN%d,%d:>%s<%s",gpib_device,ibsta&TIMO,msg,msg2);
    j=inputi;
    dso(input[j],80-55,7+1,55,color);
    for(i=1; i<7; i++)
    {
	if (--j==-1) j=6;
	dso(input[j],80-55,7+1-i,55,color-8);
    }
    mvcrsr( 8,56+7);
}

/*****************************************************************************
 *****************************************************************************/

void ibcmdbd(bd,msg,cnt)
int bd,cnt;
char msg[];
{
    char cmd[2];

    cmd[0]=32+gpib_device;
    cmd[1]=64+gpib_PC;
    ibcmd(bd,"?_",2);    /* set GPIB to UNL, UNT */
    ibcmd(bd,cmd,2);
    ibcmd(bd, msg,cnt);
}

/*****************************************************************************
 *****************************************************************************/

int init_board(void)
    {
    short  bd,i,m;        /* address of the GPIB board in the PC */
    double j,k;
    char msg[100], msg2[100];


    ibsta=0;
    bd=ibfind("GPIB0");   /* do ibfind to lock in on the addr of GPIB board */
    if (bd<0)   /* negative value means GPIB.COM was not loaded at boot time */
	{
    f_dspstg("Error, Board name GPIB0 not found.                "
	     "Check DEVICE=GPIB.COM in CONFIG.SYS               ",100,14,20);
	bd=-1;
	return(-1);
	}
		/* set up GPIB board for active communication with scope */
    ibonl(bd,0);            /* do a board reset */
    ibonl(bd,1);            /* place board online */
    ibcac(bd,1);            /* set GPIB board to control in charge */
    ibrsc(bd,1);            /* request system control */
    ibsre(bd, 1);           /* set remote enable to true */
    ibsic(bd);              /* send interface clear */
    if (ibsta & ERR)
	{
	f_dspstg("Error, GPIB board configuration, check GPIB.COM",47,14,20);
	bd=-1;
	return(-1);
	}
    ibeos(bd, 0);           /* set End-Of-String terminater to false */
    ibeot(bd, 1);           /* set EOI at end of write to true */
    ibpad(bd, gpib_PC);/* set the GPIB board address to zero */
    ibtmo(bd,10);           /* set the timeout limit to 300m second(s) */
    ibloc(bd);

#if 0
    ibdma(bd, 1);
    if (ibsta & ERR)
	{
	/*f_dspmsg(" (Press any key to continue) ",29,11,13);*/
	?_text("Warning, DMA not enabled, check GPIB.COM",9,10,12);
	/*i=intin();*/
	}
#endif

    return(bd);
    }

/*****************************************************************************
 *****************************************************************************/

int find_device(int bd, char test[])
    {
    short  i,m;   /* address of the GPIB board in the PC */
    double j,k;
    char msg[100], msg2[100];

    ibcmdbd(bd,"\x04",1);    /* send device clear before starting off */
    ibcnt=0;

    ibtmo(bd,10);           /* set the timeout limit to 300m second(s) */
    ibwrtbd(bd,"header on;*idn?",15);
    if ( ibsta & (TIMO | ERR)) /* did the PC handshake all the chars to the scope */
	{
	sprintf(msg,"Unable to send *IDN? to %s at address %d.",test,gpib_device);
	f_dspmsg(msg,strlen(msg),14,20);
	wait_here(100);
	ibtmo(bd,12);               /* set the timeout limit to 3000m second(s) */
	return(-2);
	}
    memset(msg,'\0',100);       /* null out the input buffer */
    ibtmo(bd,12);               /* set the timeout limit to 3000m second(s) */
    ibrdbd(bd,msg,100);         /* read the query response from the scope */
    if ( ibcnt < 3 )
	{
	sprintf(msg,"Unable to read from to %s at address %d.",test,gpib_device);
	f_dspmsg(msg,strlen(msg),14,20);
	wait_here(100);
	return(-3);
	}
    if (strtest(msg,test)==-1)
	{
	sprintf(msg,"Device '%s' not found at address %d.",test,gpib_device);
	f_dspmsg(msg,strlen(msg),14,20);
	wait_here(100);
	return(-3);
	}
    ibwrtbd(bd,"OPTIONS?",8);
    memset(msg2,0,100);
    ibrdbd(bd,msg2,100);
    if (strtest(msg2,"32K")==-1 && strtest(msg2,"128K")==-1)
    {
	ibwrtbd(bd,"OPTIONS?",8);
	memset(msg2,0,100);
	ibrdbd(bd,msg2,100);
	if (strtest(msg2,"32K")==-1 && strtest(msg2,"128K")==-1)
	{
		strcpy(msg,"The extended-memory not installed in this unit.");
		strcat(msg, msg2);
		f_dspmsg(msg,strlen(msg),14,20);
		wait_here(100);
		return(-3);
	}
    }
    strcpy(options, msg2);
    return(bd);
}

/*****************************************************************************
 *****************************************************************************/

int find_both_devices(void)
{
	bd=init_board();
	gpib_device=CSA907AT;
	find_device(bd, "CSA907AT");
	gpib_device=CSA907AR;
	find_device(bd, "CSA907AR");
	return(bd);
}

/*****************************************************************************
 *****************************************************************************/

void send_data(int bd, int location)
{
    unsigned int i,j,k,m,n,bytes,bits,total,databyte,ones=0;
    char msg[100],msg2[100],buffer2[10],big_save[1000];
    unsigned char *temp, flag, *buffer1;

    total=datalen; 
    i=total;
    temp=(unsigned char huge *)(_fmalloc(i));
    if (temp==NULL)          
	{
		sprintf(msg," You need at least %dk bytes more memory. ",
			i/1024 +1);
		f_dsperr(msg,strlen(msg),11,20);
		i=intin();
		f_dsperr("Error, low memory - check CONFIG.SYS / AUTOEXEC.BAT",
			51,10,10);
		return;
	}

    for (i=0; i<datalen; i++)
	temp[i]=data[i];


    sprintf(msg,"EDIT_BEGIN %d",location);
    ibwrtbd(bd,msg,strlen(msg));

    sprintf(msg,"WORD_ORD MSB");
    ibwrtbd(bd,msg,strlen(msg));

    bits=total%8;
    bytes=total/8;
    sprintf(msg,"BYTE_LENGTH %d,%d",bytes,bits);
    ibwrtbd(bd,msg,strlen(msg));

    j=bytes/10; k=bytes%10;
    for(i=0;i<j;i++)
	{
	    sprintf(msg,"BYTE_BLOCK %d,80",i*10);
	    for (m=0;m<10;m++)
		{
		    for (n=0,databyte=0;n<8;n++)
			databyte |= temp[i*10*8 + m*8 + n]<<( 7-  n);
		    sprintf(msg2,",#H%2.2X",databyte);
		    strcat(msg,msg2);
		}
	    ibwrtbd(bd,msg,strlen(msg));
	    sprintf(msg,"%d ",(j-i)*10*8-m);
	    dso(msg,strlen(msg),14+1,20+44,3*16+1);
	}

    sprintf(msg,"BYTE_BLOCK %d,%d",i*10,k*8);
    for(m=0;m<k;m++)
	{
	    for (n=0,databyte=0;n<8;n++)
		databyte |= temp[i*10*8 + m*8 + n]<<( 7 -  n);
	    sprintf(msg2,",#H%2.2X",databyte);
	    strcat(msg,msg2);
	}
    ibwrtbd(bd,msg,strlen(msg));

    dso(" . . .",6,14+1,20+44,3*16+1);
    if (bits>0)
	{
	    sprintf(msg,"BYTE_BLOCK %d,%d",i*10 + k,bits);
	    for (n=0,databyte=0;n<bits;n++)
		databyte |= temp[i*10*8 + m*8 + n]<<( 7 -  n);
	    sprintf(msg2,",#H%2.2X",databyte);
	    strcat(msg,msg2);
	    ibwrtbd(bd,msg,strlen(msg));
	}

    sprintf(msg,"EDIT_END %d",location);
    ibwrtbd(bd,msg,strlen(msg));

    _ffree((unsigned char huge *)(temp));

}

/*****************************************************************************
 *****************************************************************************/

void display_current_task(char *msg, int color)
{
	char msg2[100];

	ftextbox(19,15,3,55,color);
	sprintf(msg2,"Current task : %s",msg);
	dso(msg2,strlen(msg2),20,16,color);
	mvcrsr(20,16+strlen(msg2)-1);
}


/*****************************************************************************
 *****************************************************************************/

void do_one_test(float freq)
{
	float temp;
	char msg[100], msg2[100];
	unsigned char rnd;
	int i, j, max_wait=5;
	long t1,t2;
	FILE *PRBS_ptr, *WORD_ptr;

	gpib_device=CSA907AT;
	ibwrtbd(bd, "DATA_PATTERN PRBS",17);
	sprintf(msg,"PRBS_LENGTH %d", 7);
	ibwrtbd(bd, msg, strlen(msg));
	sprintf(msg,"CLOCK_FREQ %E", freq);
	ibwrtbd(bd, msg, strlen(msg));

	gpib_device=CSA907AR;
	ibwrtbd(bd, "HEADER OFF; AUTO_SEARCH OFF",28);
	ftextbox(22,22,3,40,color);

	time(&t1);
	do
	{
		ibwrtbd(bd, "CLOCK_FREQ?",11);
		memset(msg,0,100);
		ibrdbd(bd, msg, 100);
		temp=atof(msg);
		sprintf(msg2,"Response >%s<",msg);
		dso(msg2,strlen(msg2),23,23,color);
		wait_here(100);
		time(&t2);
		if (nxtchr()!=0) i=intin();
	} while ( (temp<freq-freq*.02 || temp>freq+freq*.02) && t2-t1<max_wait);

	if (t2-t1>=max_wait)
	{
		display_current_task("PLL test FAILED !!!", bad_color);
		wait_here(100);
	}

	ibwrtbd(bd, "AUTO_SEARCH AUTO",16);
	time(&t1);
	do
	{
		sprintf(msg,"PRBS Sync locking ...");
		dso(msg,strlen(msg),23,23,color);
		wait_here(100);
		ibwrtbd(bd, "SYNC?", 5);
		memset(msg,0,100);
		ibrdbd(bd, msg, 100);
		time(&t2);
		if (nxtchr()!=0) i=intin();
	} while (msg[1]!='N' && t2-t1<max_wait);

	if (t2-t1>=max_wait)
	{
		sprintf(msg2, "SyncLock FAILED!");
		display_current_task(msg2, bad_color);
		wait_here(100);
	}
	else
	{
		sprintf(msg,"PRBS Sync locked !!!           ");
		dso(msg,strlen(msg),23,23,color);
	}


	do
		rnd=rand()&255;
	while ( rnd==255 || rnd==0);
	ibwrtbd(bd, "AUTO_SEARCH OFF",15);

	gpib_device=CSA907AT;
	i=(int)rnd;
	j=i;
	sprintf(msg, "WORD_ORD MSB");
	ibwrtbd(bd, msg, strlen(msg));
	sprintf(msg, "WORD_LENGTH 8; WORD_BITS 8, #H%X", i);
	ibwrtbd(bd, msg, strlen(msg));
	sprintf(msg, 
	 "EDIT_BEGIN -1; BYTE_LENGTH 1,0; BYTE_EDIT 0,#H%X; EDIT_END -1", i);
	ibwrtbd(bd, msg, strlen(msg));
	ibwrtbd(bd, "DATA_PATTERN WORD",17);

	gpib_device=CSA907AR;
	sprintf(msg, "WORD_ORD MSB");
	ibwrtbd(bd, msg, strlen(msg));
	sprintf(msg, "WORD_LENGTH 8; WORD_BITS 8, #H%X", i);
	ibwrtbd(bd, msg, strlen(msg));
	sprintf(msg, 
	 "EDIT_BEGIN -1; BYTE_LENGTH 1,0; BYTE_EDIT 0,#H%X; EDIT_END -1", i);
	ibwrtbd(bd, msg, strlen(msg));
	/* PATTERN doesn't like being ahead of 'BITS' !!?? */
	ibwrtbd(bd, "DATA_PATTERN WORD",17);
	time(&t1);
	do
	{
		sprintf(msg,"Word Sync locking ...");
		dso(msg,strlen(msg),23,23,color);
		wait_here(20);
		ibwrtbd(bd, "SYNC?", 5);
		memset(msg,0,100);
		ibrdbd(bd, msg, 100);
		time(&t2);
		if (nxtchr()!=0) i=intin();
	} while (msg[1]!='N' && t2-t1<max_wait);

	if (t2-t1>=max_wait)
	{
		display_current_task("Word SyncLock test FAILED !!!", 
			bad_color);
		wait_here(100);
	}
	else
	{
		sprintf(msg,"Word Sync locked !!!                ");
		dso(msg,strlen(msg),23,23,color);
	}

}

/*****************************************************************************
 *****************************************************************************/

void do_all_tests(int cmi)
{
	float temp;
	char msg[100], msg2[100];
	int pattern_mode, pattern_type;

	display_current_task("Checking for Sync Lock on PRBS", color);

	gpib_device=CSA907AT;
	sprintf(msg,"DATA_INVERT OFF; ERROR_RATE OFF");
	ibwrtbd(bd, msg, strlen(msg));

	if (cmi==0)
		do_one_test((float)140.0E+6);
	else
		do_one_test((float)280.0E+6);
	gpib_device=CSA907AR;
	ibwrtbd(bd, "HEADER ON",9);
}

/*****************************************************************************
 *****************************************************************************/

void init_colors(void)
{
	if ( *(char far *)0x00400049 == 7 )
	{
		f_colorbfr(2,0,14);
		f_colorerr(2,14);
		f_colormsg(2,0,14);
		f_colorstg(2,0,14);
		f_coloredln(2,0,15,0,15);
	}

	dso_init();                        /* initialize dso() address */
}

/*****************************************************************************
 *****************************************************************************/

long getlen(char *data_in)  
    {
    int  DTATME=22;    /* was 18    */
    int  optn=2, buf_len=100;
    char data_out[100];                    /* output area */

    char *ccp;
    char  dta[44], fn_buf[80], tmp_chr[10], new_stg[40];
    char far *mp;
    int i, ret, nbr_fnd, len_ent, tmp_int, ii;
    long  lng_int;
    union REGS in,out;
    struct SREGS sr;
    lng_int = 0;
    tmp_int = 0;
    nbr_fnd = 0;                       /* initialize number found */
    len_ent = 9;                       /* initialize entry length */
    if (optn == 1)                     /* option 1 */
	len_ent = 13;                  /*   name and extension    */
    if (optn == 2)                     /* option 2 */
	len_ent = 22;                  /*   name & ext & size     */
    if (optn == 3)                     /* option 3 */
	len_ent = 38;                  /*   name-ext-size-datetime */
    data_out[0] = '\0';
    segread(&sr);
    memset(fn_buf,'\0',sizeof(fn_buf));  /* set file buffer to NULL */
    strcpy(fn_buf,data_in);            /* copy input string */
    mp = (char far *) dta;             /* address of 'dta' */
    sr.ds = FP_SEG(mp);
    in.x.dx = FP_OFF(mp);
    in.h.ah = 26;
    ret = intdosx(&in,&out,&sr);

    mp = (char far *)fn_buf;           /* find first matching file */
    sr.ds = FP_SEG(mp);
    in.x.dx = FP_OFF(mp);
    in.h.cl = 32;                      /* match on archive bit */
    in.h.ah = 0x4e;                    /* find first matching file */
    ret = intdosx(&in,&out,&sr);

    if  ((out.x.ax == 18) && (_osmajor == 3))  /* DOS 3.0 or 3.1 */
	return(0);                     /* no files available */
    if (out.x.ax > 0 && out.x.ax < 255)
	return(-1);                    /* disk i/o error */

	memset(new_stg,' ',sizeof(new_stg));
	if (len_ent > 9)
	    {
	    new_stg[8] = '.';
	    new_stg[13] = '\0';        /* terminate string */
	    }
	else
	    new_stg[9] = '\0';         /* terminate string */
	for (ii=0; ii<9 && dta[DTATME+8+ii] != '.' &&
		    dta[DTATME+8+ii] > 31 && dta[DTATME+8+ii] < 128; ++ii)
	    {
	    new_stg[ii] = dta[DTATME+8+ii];
	    }
	if (len_ent > 9 &&             /* option 1, 2 or 3 */
	       dta[DTATME+8+ii] == '.')
	    {
	    if (dta[DTATME+8+ii+1] > 31 && dta[DTATME+8+ii+1] < 128)
		{
		new_stg[9] = dta[DTATME+8+ii+1];
		if (dta[DTATME+8+ii+2] > 31 && dta[DTATME+8+ii+2] < 128)
		    {
		    new_stg[10] = dta[DTATME+8+ii+2];
		    if (dta[DTATME+8+ii+3] > 31 && dta[DTATME+8+ii+3] < 128)
			new_stg[11] = dta[DTATME+8+ii+3];
		    }
		}
	    }

	if (len_ent > 13)              /* option 2 or 3 */
	    {
	    ccp = (char *) &lng_int;
	    ccp[0] = dta[DTATME+4];   /* get size */
	    ccp[1] = dta[DTATME+5];
	    ccp[2] = dta[DTATME+6];
	    ccp[3] = dta[DTATME+7];
	    ret = sprintf(&tmp_chr[0],"%8ld",lng_int);
	    strcat(new_stg,tmp_chr);
	    strcat(new_stg," ");
	    return((long)(lng_int));
	    }
}

/*****************************************************************************
 *****************************************************************************/

int read_wfm(char filename[])                     /* read waveform from disk */
    {
    FILE *wfmfp;
    FILE *fopen();

    int  i,j,k,l,nbr_ent, ln_ent, ret1, ret;
    long filelen;
    char *buffer, *rfname, *saveit, msg[100];
    char *tmp, *tname, *d_stg, *p, symbol,local;


    buffer=malloc(1300);    rfname=malloc(50);
    saveit=malloc(900);    tmp   =malloc(100);
    tname =malloc(20);    d_stg =malloc(50);
    if (buffer==NULL || rfname==NULL || saveit==NULL || tmp==NULL ||
	tname ==NULL || d_stg ==NULL) 
	{
	f_dsperr("Memory Error.              ",27,ROWA,COLA);
	free(buffer);   free(rfname);
	free(saveit);   free(tmp);
	free(tname);    free(d_stg);
	return(-1);
	}
    wfmfp = fopen(filename,"r");        /* open file */
    if (wfmfp == NULL)
	{
	if (ret==0)
		f_dsperr("Error, Open failed for file",27,ROWA,COLA);
	free(buffer);   free(rfname);
	free(saveit);   free(tmp);
	free(tname);    free(d_stg);
	return(-1);
	}

	    fclose(wfmfp);                     /* close file */
	    filelen=getlen(filename);
	    wfmfp = fopen( filename, "r");
	    /* Read data from file and total it. */

	    fsavbox(saveit,0,ROWB,COLB,6,52); /* start at col 16 */
	    sprintf(tmp,"||||||||||||||||||||||||||||||||||||||||||||||||||"
			"Loading: %s",filename);
	    f_dspmsg(tmp,strlen(tmp),ROWB,COLB);
	    sprintf(msg,"%6ld bytes",filelen);
	    dso(msg,strlen(msg),ROWB+2,(int)(COLB+46-7),1+16*3+8);
	    if (filelen>49*2)
		wait_here(50);

	    i=-1;
	    ret=-1;
	    memset(data,0,(unsigned int)32768);
	    do
	    {
		    k=48*(long)i*2.0/(long)filelen;
		    if (k>48) k=48;
		    if (k<0) k=0;
		    dso("-",1,ROWB+1,(int)(COLB+k+1),1+16*3+8);
		    dso(">",1,ROWB+1,(int)(COLB+k+2),1+16*3+128+8);
		    sprintf(msg,"%6ld",(long)(filelen-i*2.0+1));
		    dso(msg,strlen(msg),ROWB+2,(int)(COLB+46-7),1+16*3+8);

		    do
			j=fscanf( wfmfp, "\t\n %c ", &symbol );
		    while (j>0 && ( symbol==',' || symbol==';' ) );
		    if (j!=-1)
		    {
			i++;
			local=symbol;
			if (local<48 || local>49)
				ret=0;
			else
				data[i]=local-48;
		    }
	    } while (j!=-1 && (unsigned int)i<32768 && ret!=0);
	    if (ret==0)
		{
		f_dsperr("Error, illegal symbol found, read stopped.",42,
			ROWA,COLA);
		datalen=(unsigned int)i+1;
		}
	    else if ((unsigned int)i>=32768)
		{
		f_dsperr("Error, too many bits, read stopped at 32768 bits.",49,
			ROWA,COLA);
		datalen=32768;
		}
	    else if (i>=4095 && (i+1)%8 !=0)
		{
		f_dspstg(
			"Warning, symbol counts greater than 4k are round- " 
			"ed using MOD 8 to fit the data into high-speed    "
			"memory ( e.g., 4096, 4104, ...   )."
			,135,ROWB,COLB);
		datalen = (((unsigned int)i+1) / 8) * 8 + 8; 
		}
	    else
		datalen=(unsigned int)i+1;
	if (filelen>49*2)
		wait_here(50);
	fresbox(saveit,0,ROWB,COLB,4,52);
	sprintf(msg,"Total bits read in = %d.",(unsigned int)datalen);
	dso(msg,strlen(msg),ROWB+1,COLB+18,1+16*3+8);
	wait_here(200);

    if (ret==0)
	{
	fclose(wfmfp);                     /* close file */
	f_dsperr("Error, Read file error",22,ROWA,COLA);
	fresbox(saveit,0,ROWB,COLB,4,52);
	free(buffer);   free(rfname);
	free(saveit);   free(tmp);
	free(tname);    free(d_stg);
	return(-1);
	}
   else
	fclose(wfmfp);                     /* close file */

    free(buffer);    free(rfname);
    free(saveit);    free(tmp);
    free(tname);    free(d_stg);
    return(0);
    } /* end read_wfm() */


/*****************************************************************************
 *****************************************************************************/

unsigned int CodeMarkInversion(char unsigned tmpdata[], char unsigned data[],
			unsigned int count, int A1, int A2)
{
	unsigned int i, tally;

	for (i=0, tally=0; i<count; i++)
	{
		if (tmpdata[i]==0)
		{
			data[i*2  ]=0;
			data[i*2+1]=1;
		}
		else
		{
			if ( (++tally & 1)==1 )
			{
				data[i*2  ]=A1;
				data[i*2+1]=A1;
			}
			else
			{
				data[i*2  ]=A2;
				data[i*2+1]=A2;
			}
		}
	}
	return(tally);
}

/*****************************************************************************
 *****************************************************************************/

void main(argc,argv)
    int argc;
    char **argv;
    {
	register char **p;
	int    i, bd, count=0, savrow, savcol, ptr_area[2000], memory=0, cmi;
	char msg[100], id[100];
	FILE   *ptr;
	char datafile[80];
	char big_save[1000];
	unsigned int ui, tally;


	if (argc!=4)
	{
		printf("\n\nError, must use all three arguments.");
		printf("\n  DOWNLOAD {ASCII file} {memory address} {CMI | NOCMI}");
		printf("\n  ( e.g., download pattern 0 nocmi )");
		exit(0);
	}

	p = argv+2;
	strcpy(msg,*p);
	if (strlen(msg)>1 || msg[0]<'0' || msg[0]>'9')
	{
		printf("\n\nError, memory address must be from 0 to 9.");
		exit(0);
	}
	else
		memory=msg[0]-48;

	p = argv+3;
	strcpy(msg,*p);
	for (i=0; i<strlen(msg); i++)
		msg[i]=toupper((int)msg[i]);
	if (strcmp(msg,"CMI")!=0 && strcmp(msg,"NOCMI")!=0)
	{
		printf("\n\nError, encoding must be cmi or nocmi.");
		exit(0);
	}
	if (strcmp(msg,"CMI")==0)
		cmi=1;
	else 
		cmi=0;

	/* Copy data following 'drive:\dir\filename.EXE'  */
	p = argv+1;
	strcpy(datafile,*p);

	/* Set message output colors */
	init_colors();

	rdcrsr(&savrow,&savcol);      /* save DOS cursor position */
	mvcrsr(0,0);                  /* remove cursor from the CRT */

	dsasave((char *)ptr_area,2000,1,1);
	clrscn();

	if (read_wfm(datafile)==-1)
		_exit(-1);

	if (cmi==1)
	{
		if (datalen> 32768/2)
		{
			printf("\n\nError, CMI not available when length > 2^14.");
			exit(0);
		}
		else if (datalen*2>4096 && (datalen*2)%8 != 0)
		{        /* divide by 8 remainder */
			printf("\n\nError, CMI not available until file is multiple of 8.");
			exit(0);
		}
		for (ui=0; ui<datalen; ui++)
			tmpdata[ui]=data[ui];
		tally=CodeMarkInversion(tmpdata, data, (unsigned int)datalen, 
			0, 1);
		if ( (tally&1)==1 )
		{       /* odd number of 1's, so concatenate and invert ... */
			if (datalen> 32768/4)
			{
				printf(
			"\n\nCMI error, out of memory (invert any single bit).");
				exit(0);
			}
			else if (datalen*4>4096 && (datalen*4)%8 != 0)
			{        /* divide by 8 remainder */
				printf(
			"\n\nError, CMI not available until file is multiple of 8.");
				exit(0);
			}
			else
			{
				tally=CodeMarkInversion(tmpdata, 
					&data[datalen*2], 
					(unsigned int)datalen, 1, 0);
				datalen *=2;
			}
		}
		datalen *=2;
	}

	for (i=0; i<6; i++)
	{
		memset(input[i],32,80);
		memset(output[i],32,80);
	}
	ftextbox(1,1,9,38+15,color);
	ftextbox(1,38+15+1,9,80-(38+15),color);

	sprintf(msg,"Searching for devices");
	display_current_task(msg, color);

	/* Check communications between the PC and the CSA907A's */
	bd=find_both_devices();

	do_all_tests(cmi);

	gpib_device=gpib_Tx;
	strcpy(id,"CSA907AT");
	if (find_device(bd,id)>=0)
	{
		ibsre(bd,1);
		ibcmdbd(bd,"\x11",1);    /* send Local Lock Out */
		sprintf(msg,"Transferring data to transmitter");
		display_current_task(msg, color);
		send_data(bd,memory); /* send data to gpib */
		ibsre(bd,0);
		ibcmdbd(bd,"\x01",1);    /* send Go To Local  */
		wait_here(50);
		sprintf(msg,"RECALL_WORD %d", memory);
		ibwrtbd(bd, msg, strlen(msg));
	}
	gpib_device=gpib_Rx;
	strcpy(id,"CSA907AR");
	if (find_device(bd,id)>=0)
	{
		ibsre(bd,1);
		ibcmdbd(bd,"\x11",1);    /* send Local Lock Out */
		sprintf(msg,"Transferring data to receiver");
		display_current_task(msg, color);
		send_data(bd,memory); /* send data to gpib */
		ibsre(bd,0);
		ibcmdbd(bd,"\x01",1);    /* send Go To Local    */
		wait_here(50);
		sprintf(msg,"RECALL_WORD %d", memory);
		ibwrtbd(bd, msg, strlen(msg));
	}

	sprintf(msg,"All done.  Press any key to exit.         ");
	display_current_task(msg, color);
	intin();
	/* Restore the DOS screen */
	dsarest((char *)ptr_area,2000,1,1);
	/* Put the DOS cursor back up */
	mvcrsr(savrow,1);
}
