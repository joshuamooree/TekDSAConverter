/* Connect clock and data out (Tx) to the clock and data in (Rx);  Addresses
   should be at the default (14,15);  Use a National Instrument GPIB card with
   the GPIB.COM file;  
*/
#include <dos.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include "fdib.h"
#include "fdlid2.h"

#define gpib_PC  0
#define datafile "WARMTEST.DAT"
#define FILE_IO 0
#define  ALTF1  232
#define  ESC     27

#define ERR     (1<<15) /* Error detected                  */
#define TIMO    (1<<14) /* Timeout                         */

/* Status variables declared public by *cib*.obj.          */
extern  int     ibsta;  /* status word                     */
extern  int     iberr;  /* GPIB error code                 */
extern  int     ibcnt;  /* number of bytes sent            */

int warmup=20, power_SRQ=1;
int CSA907AR=14;
int CSA907AT=15;
int gpib_device, bd;
int color=15+16*1;
int bad_color=14+16*4;
long   ltime;
int PN[]={ 7, 15, 17, 20, 23, 7, 15, 17 };
int index=0;
int totally_bad=0;
int TWO_PAIRS=0;
int PNMAX=0, MAXTIME=0;

int inputi=6, outputi=6;
char output[7][180];
char  input[7][180];
char options[100];

/*****************************************************************************
 *****************************************************************************/

int strtest(msg1,msg2)

char msg1[],msg2[];
{
	int l1,l2,found,i,j,k,m;

	l1=strlen(msg1); l2=strlen(msg2);
	for (i=0,j=0,found=-1; i<l1 && j<l2 && found<0; i++)
	{
		if (msg1[i]==msg2[0])
		{
			for(k=i,j=0;k<l1 && j<l2 && msg1[k]==msg2[j];k++,j++);
			if (j==l2) found=i;
		}
	}
	return(found);
}

/*****************************************************************************
 *****************************************************************************/

void clear_base(void)
{
		dso("                                                  ",
			50,22,22,color);
		dso("                                                  ",
			50,23,22,color);
		dso("                                                  ",
			50,24,22,color);
}

/*****************************************************************************
 *****************************************************************************/

void display_elapsed_time(long ltime, int first_time)
  {
	long temp, ltime2;
	long days, hours, minutes, seconds;
	char msg[100];

	time(&ltime2);
	temp    = ltime2-ltime;
	days    = temp/24/60/60;
	temp   -= days*24*60*60;
	hours   = temp/60/60;
	temp   -= hours*60*60;
	minutes = temp/60;
	temp   -= minutes*60;
	seconds = temp;

	if (first_time==1)
		ftextbox(6+3+2,45,5,34,color);
	sprintf(msg,"Total elapsed time :");
	dso(msg,strlen(msg),6+4+2,46,color);
	sprintf(msg,"Days:%2.2d, Hours:%2.2d, ",(int)days,(int)hours);
	dso(msg,strlen(msg),6+5+2,48,color-8);
	sprintf(msg,"Minutes:%2.2d, Seconds:%2.2d",(int)minutes,(int)seconds);
	dso(msg,strlen(msg),6+6+2,48,color-8);
}

/*****************************************************************************
 *****************************************************************************/

void get_time(int *hours, int *minutes, int *seconds)
{
	long   ltime;
	char   chr_time[26];

	time(&ltime);
	sprintf(chr_time,"%s",ctime(&ltime));

	*hours =   (chr_time[11]-'0')*10 + chr_time[12]-'0';
	*minutes = (chr_time[14]-'0')*10 + chr_time[15]-'0';
	*seconds = (chr_time[17]-'0')*10 + chr_time[18]-'0';
}

/*****************************************************************************
 *****************************************************************************/

void get_date(int *month, int *day, int *year)
{
	char a_date[10];

	_strdate(a_date);
	*month = (a_date[0]-'0')*10 + a_date[1]-'0';
	*day   = (a_date[3]-'0')*10 + a_date[4]-'0';
	*year  = (a_date[6]-'0')*10 + a_date[7]-'0';

}

/*****************************************************************************
 *****************************************************************************/

void display_current_time(void)
{
	int hours, minutes, seconds, month, day, year;
	char msg[100];

	get_time(&hours, &minutes, &seconds);
	get_date(&month, &day, &year);

	sprintf(msg,"Current date & time :");
	dso(msg,strlen(msg),14+2,4,color);
	sprintf(msg,"%2.2d-%2.2d-19%2.2d",month, day, year);
	dso(msg,strlen(msg),15+2,6,color-8);
	sprintf(msg,"%2.2d:%2.2d:%2.2d", hours, minutes, seconds);
	dso(msg,strlen(msg),15+2,6+13,color-8);
}

/*****************************************************************************
 *****************************************************************************/

void display_total_test_count(int count)
{
	char msg[100];

	ftextbox(13+2+1,45,3,35-1,color);
	sprintf(msg,"Tests completed:%d  PN%d@%d",count, PNMAX, MAXTIME);
	dso(msg,strlen(msg),14+2+1,46,color);
}

/*****************************************************************************
 *****************************************************************************/

void wait_here(int timeout /* in tens of milli-seconds */)
{

	int start,  delta;
	union REGS inregs, outregs;

	inregs.h.ah = 0x2c;
	intdos(&inregs,&outregs);
	start = outregs.h.dh * 100 + outregs.h.dl; /* start time */
	delta = 0;
	while (delta < timeout)
	{
	    intdos(&inregs,&outregs);             /* get current time */
	    delta = outregs.h.dh * 100 + outregs.h.dl - start;
	    if (delta < 0)
		{
		start = start - 60 * 100;
		delta = 60 * 100 + delta;
		}
	}
}

/*****************************************************************************
 *****************************************************************************/

void wait_minutes(int timeout /* in minutes */)
{
	int hours, minutes, seconds, month, day, year;
	char msg[100];
	long start,  temp, delta, t1,t2,t3, i;

	get_time(&hours, &minutes, &seconds);
	start = seconds + minutes*60 + (long)hours*60*60; /* start time */
	delta = 0;
	ftextbox(22,22,3,40,color);
	while (delta < (long)timeout*60 && nxtchr()!=ALTF1)
	{
		/* get current time */
		get_time(&hours, &minutes, &seconds);
		temp = seconds + minutes*60 + (long)hours*60*60;
		if (temp<start)
		    temp+=86400;
		delta = temp - start;
		temp    = (long)timeout*60 - delta;
		hours   = temp/60/60;
		temp   -= hours*60*60;
		minutes = temp/60;
		temp   -= minutes*60;
		seconds = temp;
		sprintf(msg,"Time left to wait %2.2d:%2.2d:%2.2d",hours, minutes,
			seconds);
		dso(msg,strlen(msg),23,23,color);
		display_elapsed_time(ltime,0);
		display_current_time();
		if (nxtchr()!=0 && nxtchr()!=ALTF1) i=intin();
	}
	clear_base();
	for (;nxtchr()!=0; intin());
}

/*****************************************************************************
 *****************************************************************************/

void ibwrtbd(bd,msg,cnt)
int bd,cnt;
char msg[];
{
    char cmd[2];
    char msg2[100];
    int i,j;

    cmd[0]=32+gpib_device;
    cmd[1]=64+gpib_PC;
    ibcmd(bd,"?_",2);    /* set GPIB to UNL, UNT */
    ibcmd(bd,cmd,2);
    ibwrt(bd, msg,cnt);

    ++outputi;
    outputi %= 7;
    sprintf(msg2,"                                                          ");
    sprintf(output[outputi],"OUT%d,%d:>%s<%s",gpib_device,ibsta&TIMO,msg,msg2);
    j=outputi;
    dso(output[j],38+13,7+1,2,color);
    for(i=1; i<7; i++)
    {
	if (--j==-1) j=6;
	dso(output[j],38+13,7+1-i,2,color-8);
    }
    mvcrsr( 8,7);
}

/*****************************************************************************
 *****************************************************************************/

void ibrdbd(bd,msg,cnt)
int bd,cnt;
char msg[];
{
    char cmd[2];
    char msg2[100], msg3[100];
    int i,j;
    
    cmd[0]=32+gpib_PC;
    cmd[1]=64+gpib_device;
    ibcmd(bd,"?_",2);    /* set GPIB to UNL, UNT */
    ibcmd(bd,cmd,2);
    ibrd(bd, msg,cnt);

    msg[ibcnt]=0;
    ++inputi;
    inputi %= 7;
    sprintf(msg2,"                                                          ");
    sprintf(input[inputi],"IN%d,%d:>%s<%s",gpib_device,ibsta&TIMO,msg,msg2);
    j=inputi;
    dso(input[j],80-55,7+1,55,color);
    for(i=1; i<7; i++)
    {
	if (--j==-1) j=6;
	dso(input[j],80-55,7+1-i,55,color-8);
    }
    mvcrsr( 8,56+7);
}

/*****************************************************************************
 *****************************************************************************/

void ibcmdbd(bd,msg,cnt)
int bd,cnt;
char msg[];
{
    char cmd[2];

    cmd[0]=32+gpib_device;
    cmd[1]=64+gpib_PC;
    ibcmd(bd,"?_",2);    /* set GPIB to UNL, UNT */
    ibcmd(bd,cmd,2);
    ibcmd(bd, msg,cnt);
}

/*****************************************************************************
 *****************************************************************************/

int init_board(void)
    {
    short  bd,i,m;        /* address of the GPIB board in the PC */
    double j,k;
    char msg[100], msg2[100];


    ibsta=0;
    bd=ibfind("GPIB0");   /* do ibfind to lock in on the addr of GPIB board */
    if (bd<0)   /* negative value means GPIB.COM was not loaded at boot time */
	{
    f_dspstg("Error, Board name GPIB0 not found.                "
	     "Check DEVICE=GPIB.COM in CONFIG.SYS               ",100,14,20);
	bd=-1;
	return(-1);
	}
		/* set up GPIB board for active communication with scope */
    ibonl(bd,0);            /* do a board reset */
    ibonl(bd,1);            /* place board online */
    ibcac(bd,1);            /* set GPIB board to control in charge */
    ibrsc(bd,1);            /* request system control */
    ibsre(bd, 1);           /* set remote enable to true */
    ibsic(bd);              /* send interface clear */
    if (ibsta & ERR)
	{
	f_dspstg("Error, GPIB board configuration, check GPIB.COM",47,14,20);
	bd=-1;
	return(-1);
	}
    ibeos(bd, 0);           /* set End-Of-String terminater to false */
    ibeot(bd, 1);           /* set EOI at end of write to true */
    ibpad(bd, gpib_PC);/* set the GPIB board address to zero */
    ibtmo(bd,10);           /* set the timeout limit to 300m second(s) */
    ibloc(bd);

#if 0
    ibdma(bd, 1);
    if (ibsta & ERR)
	{
	/*f_dspmsg(" (Press any key to continue) ",29,11,13);*/
	?_text("Warning, DMA not enabled, check GPIB.COM",9,10,12);
	/*i=intin();*/
	}
#endif

    return(bd);
    }

/*****************************************************************************
 *****************************************************************************/

int find_device(int bd, char test[])
    {
    short  i,m;   /* address of the GPIB board in the PC */
    double j,k;
    char msg[100], msg2[100];

    ibcmdbd(bd,"\x04",1);    /* send device clear before starting off */
    ibcnt=0;

    ibtmo(bd,10);           /* set the timeout limit to 300m second(s) */
    ibwrtbd(bd,"header on;*idn?",15);
    if ( ibsta & (TIMO | ERR)) /* did the PC handshake all the chars to the scope */
	{
	sprintf(msg,"Unable to send *IDN? to %s at address %d.",test,gpib_device);
	f_dspmsg(msg,strlen(msg),14,20);
	wait_here(100);
	ibtmo(bd,12);               /* set the timeout limit to 3000m second(s) */
	return(-2);
	}
    memset(msg,'\0',100);       /* null out the input buffer */
    ibtmo(bd,12);               /* set the timeout limit to 3000m second(s) */
    ibrdbd(bd,msg,100);         /* read the query response from the scope */
    if ( ibcnt < 3 )
	{
	sprintf(msg,"Unable to read from to %s at address %d.",test,gpib_device);
	f_dspmsg(msg,strlen(msg),14,20);
	wait_here(100);
	return(-3);
	}
    if (strtest(msg,test)==-1)
	{
	sprintf(msg,"Device '%s' not found at address %d.",test,gpib_device);
	f_dspmsg(msg,strlen(msg),14,20);
	wait_here(100);
	return(-3);
	}
    ibwrtbd(bd,"OPTIONS?",8);
    memset(msg2,0,100);
    ibrdbd(bd,msg2,100);
    if (strtest(msg2,"32K")==-1 && strtest(msg2,"128K")==-1)
    {
	ibwrtbd(bd,"OPTIONS?",8);
	memset(msg2,0,100);
	ibrdbd(bd,msg2,100);
	if (strtest(msg2,"32K")==-1 && strtest(msg2,"128K")==-1)
	{
		strcpy(msg,"The 32k/128k not installed in this unit.");
		strcat(msg, msg2);
		f_dspmsg(msg,strlen(msg),14,20);
		wait_here(100);
		return(-3);
	}
    }
    strcpy(options, msg2);
    ibwrtbd(bd,"WORD_ORDER LSB",14);
    return(bd);
}

/*****************************************************************************
 *****************************************************************************/

int find_device_save(int bd, char test[])
    {
    short  i,m;   /* address of the GPIB board in the PC */
    double j,k;
    char msg[100], msg2[100];

    ibcmdbd(bd,"\x04",1);    /* send device clear before starting off */
    ibcnt=0;

    ibtmo(bd,10);           /* set the timeout limit to 300m second(s) */
    ibwrtbd(bd,"header on;*idn?",15);
    if ( ibsta & (TIMO | ERR)) /* did the PC handshake all the chars to the scope */
	{
	sprintf(msg,"Unable to send *IDN? to %s at address %d.",test,gpib_device);
	f_dspstg(msg,strlen(msg),14,20);
	i=intin();  /* eat one char from the KBD */
	return(-2);
	}
    memset(msg,'\0',100);       /* null out the input buffer */
    ibtmo(bd,12);               /* set the timeout limit to 3000m second(s) */
    ibrdbd(bd,msg,100);         /* read the query response from the scope */
    if ( ibcnt < 3 )
	{
	sprintf(msg,"Unable to read from to %s at address %d.",test,gpib_device);
	f_dspstg(msg,strlen(msg),14,20);
	i=intin();  /* eat one char from the KBD */
	return(-3);
	}
    if (strtest(msg,test)==-1)
	{
	sprintf(msg,"Device '%s' not found at address %d.",test,gpib_device);
	f_dspstg(msg,strlen(msg),14,20);
	i=intin();  /* eat one char from the KBD */
	return(-3);
	}
    ibwrtbd(bd,"OPTIONS?",8);
    memset(msg2,0,100);
    ibrdbd(bd,msg2,100);
    if (strtest(msg2,"32K")==-1)
    {
	ibwrtbd(bd,"OPTIONS?",8);
	memset(msg2,0,100);
	ibrdbd(bd,msg2,100);
	if (strtest(msg2,"32K")==-1)
	{
		strcpy(msg,"The 32k option is not installed in this unit.");
		strcat(msg, msg2);
		f_dspstg(msg,strlen(msg),14,20);
		i=intin();  /* eat one char from the KBD */
		return(-3);
	}
    }
    strcpy(options, msg2);
    ibwrtbd(bd,"WORD_ORDER LSB",14);
    return(bd);
}

/*****************************************************************************
 *****************************************************************************/

int find_both_devices(void)
{
	bd=init_board();
	gpib_device=CSA907AT;
	find_device(bd, "CSA907AT");
	gpib_device=CSA907AR;
	find_device(bd, "CSA907AR");
	return(bd);
}

/*****************************************************************************
 *****************************************************************************/


void display_start_time(int *hours, int *minutes, int *seconds,
			int *month, int *day, int *year)
{
	char msg[100];

	get_time(hours, minutes, seconds);
	get_date(month, day, year);

	if (*year<90)
	{
		printf("'DATE' not set correctly.\n");
		exit(-1);
	}
	ftextbox(10,1,25-9,80,color);
	ftextbox(6+3+2,3,4,35,color);
	sprintf(msg,"Program start date & time :");
	dso(msg,strlen(msg),6+4+2,4,color);
	sprintf(msg,"%2.2d-%2.2d-19%2.2d",*month, *day, *year);
	dso(msg,strlen(msg),6+5+2,6,color-8);
	sprintf(msg,"%2.2d:%2.2d:%2.2d", *hours, *minutes, *seconds);
	dso(msg,strlen(msg),6+5+2,6+13,color-8);
}

/*****************************************************************************
 *****************************************************************************/


void display_current_task(char *msg, int color)
{
	char msg2[100];

	ftextbox(19,15,3,55,color);
	sprintf(msg2,"Current task : %s",msg);
	dso(msg2,strlen(msg2),20,16,color);
	mvcrsr(20,16+strlen(msg2)-1);
}

/*****************************************************************************
 *****************************************************************************/

void wait_for_power_SRQ(int bd)
{
	char msg[100];
	int SRQ=0, i;
	long temp;

	display_current_task("Waiting for CSA907AT power-on SRQ ...", color);
	ftextbox(13+2,3,4,35,color);
	gpib_device=CSA907AT;
	do
	{
		display_current_time();
		display_elapsed_time(ltime,0);
		ibwrtbd(bd, "*ESR?", 5);
		if ( (ibsta & TIMO)!=TIMO)
		{
			memset(msg,0,100);
			ibrdbd(bd, msg, 100);
			SRQ=atoi(msg) & 128;
		}
		if (nxtchr()!=0 && nxtchr()!=ALTF1) i=intin();
	} while (SRQ!=128 && nxtchr()!=ALTF1);
	for (;nxtchr()!=0; intin());
	display_current_task("Waiting for CSA907AR power-on SRQ ...", color);
	ftextbox(13+2,3,4,35,color);
	gpib_device=CSA907AR;
	SRQ=0;
	do
	{
		display_current_time();
		display_elapsed_time(ltime,0);
		ibwrtbd(bd, "*ESR?", 5);
		if ( (ibsta & TIMO)!=TIMO)
		{
			memset(msg,0,100);
			ibrdbd(bd, msg, 100);
			SRQ=atoi(msg) & 128;
		}
		if (nxtchr()!=0 && nxtchr()!=ALTF1) i=intin();
	} while (SRQ!=128 && nxtchr()!=ALTF1);
	for (;nxtchr()!=0; intin());
}

/*****************************************************************************
 *****************************************************************************/

void do_one_test(float freq, char automode[])
{
	float temp;
	char msg[100], msg2[100];
	unsigned char rnd;
	int i, j, max_wait=360;
	long t1,t2;
	FILE *PRBS_ptr, *WORD_ptr;

	gpib_device=CSA907AT;
	ibwrtbd(bd, "DATA_PATTERN PRBS",17);
	j=rand() & 7;
	sprintf(msg,"PRBS_LENGTH %d", PN[j]);
	ibwrtbd(bd, msg, strlen(msg));
	sprintf(msg,"CLOCK_FREQ %E", freq);
	ibwrtbd(bd, msg, strlen(msg));

	gpib_device=CSA907AR;
	sprintf(msg,"HEADER OFF; AUTO_SEARCH %s", automode); 
	ibwrtbd(bd, msg, strlen(msg));
	ftextbox(22,22,3,40,color);

	time(&t1);
	do
	{
		ibwrtbd(bd, "CLOCK_FREQ?",11);
		memset(msg,0,100);
		ibrdbd(bd, msg, 100);
		temp=atof(msg);
		sprintf(msg2,"Response >%s<",msg);
		dso(msg2,strlen(msg2),23,23,color);
		wait_here(50);
		time(&t2);
		if (nxtchr()!=0) i=intin();
	} while ( (temp<freq-freq*.02 || temp>freq+freq*.02) && t2-t1<max_wait);
	if (t2-t1>MAXTIME)
	{
		PNMAX=0;
		MAXTIME=t2-t1;
	}
	if (t2-t1>=max_wait)
	{
		display_current_task("PLL test FAILED !!!", bad_color);
		clear_base();
		ftextbox(22,15,3,40,color);
		sprintf(msg2,"Response >%s<",msg);
		dso(msg2,strlen(msg2),23,16,color);
		totally_bad++;
		sprintf(msg2,"BAD %d ",totally_bad);
		dso(msg2,strlen(msg2),25,1,color);
		for (;intin()!=ALTF1;);
		display_current_task("PLL test FAILED !!!", color);
		clear_base();
	}

	if (automode[0]=='O') /* "OFF" */
		ibwrtbd(bd, "AUTO_SEARCH AUTO",16);
	else 	
	{	/* "AUTO" */
		sprintf(msg,"DATA_INVERT ON");    /* ??? FAILS TO WORK ! ??? */
		ibwrtbd(bd, msg, strlen(msg));
	}
	if (FILE_IO==1)
		PRBS_ptr=fopen(datafile, "a");
	time(&t1);
	do
	{
		display_current_time();
		display_elapsed_time(ltime,0);
		sprintf(msg,"PRBS Sync locking ...");
		dso(msg,strlen(msg),23,23,color);
		wait_here(50);
		ibwrtbd(bd, "SYNC?", 5);
		memset(msg,0,100);
		ibrdbd(bd, msg, 100);
		time(&t2);
		if (nxtchr()!=0) i=intin();
	} while (msg[1]!='N' && t2-t1<max_wait);
	if (t2-t1>MAXTIME)
	{
		PNMAX=PN[j];
		MAXTIME=t2-t1;
	}
	if (FILE_IO==1)
	{
		sprintf(msg,"%d, \t%ld, \t%ld,\t\"EQ\"\n", ++index, t1-ltime, t2-t1);
		fwrite(msg,strlen(msg),1,PRBS_ptr);
		fclose(PRBS_ptr);
	}
	if (t2-t1>=max_wait)
	{
		sprintf(msg2, "SyncLock FAILED!  PN%d", PN[j]);
		display_current_task(msg2, bad_color);
		clear_base();
		totally_bad++;
		sprintf(msg2,"BAD %d ",totally_bad);
		dso(msg2,strlen(msg2),25,1,color);
		for (;intin()!=ALTF1;);
		display_current_task("SyncLock test FAILED !!!", color);
	}

	sprintf(msg,"PRBS Sync locked !!!           ");
	dso(msg,strlen(msg),23,23,color);
	sprintf(msg,"SYNC?");
	ibwrtbd(bd, msg, strlen(msg));
	memset(msg,0,100);
	ibrdbd(bd, msg, 100);

	sprintf(msg,"ERROR_RESET; HISTRY_CLEAR");
	ibwrtbd(bd, msg, strlen(msg));
	wait_here(50);
	sprintf(msg,"SYNC?");
	ibwrtbd(bd, msg, strlen(msg));
	memset(msg,0,100);
	ibrdbd(bd, msg, 100);

	gpib_device=CSA907AT;
	sprintf(msg,"ERROR_SINGLE");
	ibwrtbd(bd, msg, strlen(msg));
	wait_here(50);

	gpib_device=CSA907AR;
	sprintf(msg,"SYNC?");
	ibwrtbd(bd, msg, strlen(msg));
	memset(msg,0,100);
	ibrdbd(bd, msg, 100);
	sprintf(msg2,"TOTAL_ERROR?");
	ibwrtbd(bd, msg2, strlen(msg2));
	memset(msg2,0,100);
	ibrdbd(bd, msg2, 100);
	sprintf(msg,"SYNC?");
	ibwrtbd(bd, msg, strlen(msg));
	memset(msg,0,100);
	ibrdbd(bd, msg, 100);
	i=atoi(msg2);
	if (i!=1)
	{
		sprintf(msg2, "PRBS Error Inject Failed");
		display_current_task(msg2, bad_color);
		clear_base();
		totally_bad++;
		sprintf(msg2,"BAD %d ",totally_bad);
		dso(msg2,strlen(msg2),25,1,color);
		for (;intin()!=ALTF1;);
		display_current_task("PRBS Error Inject Failed", color);
	}

	do
		rnd=rand()&255;
	while ( rnd==255 || rnd==0);
	ibwrtbd(bd, "AUTO_SEARCH OFF",15);

	gpib_device=CSA907AT;
	i=(int)rnd;
	j=i;
	sprintf(msg, "WORD_LENGTH 8; WORD_BITS 8, #H%X", i);
	ibwrtbd(bd, msg, strlen(msg));
	sprintf(msg, "EDIT_BEGIN -1; BYTE_LENGTH 1,0; BYTE_EDIT 0,#H%X; EDIT_END -1", i);
	ibwrtbd(bd, msg, strlen(msg));
	ibwrtbd(bd, "DATA_PATTERN WORD",17);

	gpib_device=CSA907AR;
	sprintf(msg, "WORD_LENGTH 8; WORD_BITS 8, #H%X", i);
	ibwrtbd(bd, msg, strlen(msg));
	sprintf(msg, "EDIT_BEGIN -1; BYTE_LENGTH 1,0; BYTE_EDIT 0,#H%X; EDIT_END -1", i);
	ibwrtbd(bd, msg, strlen(msg));
	/* PATTERN doesn't like being ahead of 'BITS' !!?? */
	ibwrtbd(bd, "DATA_PATTERN WORD",17);
	time(&t1);
	do
	{
		display_current_time();
		display_elapsed_time(ltime,0);
		sprintf(msg,"Word Sync locking ...");
		dso(msg,strlen(msg),23,23,color);
		wait_here(50);
		ibwrtbd(bd, "SYNC?", 5);
		memset(msg,0,100);
		ibrdbd(bd, msg, 100);
		time(&t2);
		if (nxtchr()!=0) i=intin();
	} while (msg[1]!='N' && t2-t1<max_wait);
	if (t2-t1>MAXTIME)
	{
		PNMAX=-j;
		MAXTIME=t2-t1;
	}
	if (t2-t1>=max_wait)
	{
		display_current_task("Word SyncLock test FAILED !!!", bad_color);
		totally_bad++;
		sprintf(msg2,"BAD %d ",totally_bad);
		dso(msg2,strlen(msg2),25,1,color);
		for (;intin()!=ALTF1;);
		display_current_task("Word SyncLock test FAILED !!!", color);
		clear_base();
	}

	sprintf(msg,"Word Sync locked !!!                ");
	dso(msg,strlen(msg),23,23,color);

	sprintf(msg,"ERROR_RESET; HISTRY_CLEAR");
	ibwrtbd(bd, msg, strlen(msg));
	wait_here(50);

	gpib_device=CSA907AT;
	sprintf(msg,"ERROR_SINGLE");
	ibwrtbd(bd, msg, strlen(msg));
	wait_here(50);

	gpib_device=CSA907AR;
	sprintf(msg,"TOTAL_ERROR?");
	ibwrtbd(bd, msg, strlen(msg));
	memset(msg,0,100);
	ibrdbd(bd, msg, 100);
	i=atoi(msg);
	if (i!=1)
	{
		sprintf(msg2, "WORD Error Inject Failed");
		display_current_task(msg2, bad_color);
		clear_base();
		totally_bad++;
		sprintf(msg2,"BAD %d ",totally_bad);
		dso(msg2,strlen(msg2),25,1,color);
		for (;intin()!=ALTF1;);
		display_current_task("WORD Error Inject Failed", color);
	}

	if (nxtchr()!=0) i=intin();
}

/*****************************************************************************
 *****************************************************************************/

void do_all_tests( float offset, float amplitude )
{
	float temp;
	char msg[100], msg2[100];
	int pattern_mode, pattern_type;

	display_current_task("Measuring CSA907A test system ...", color);

	gpib_device=CSA907AT;
	sprintf(msg,"CLOCK_OFFSET %E; CLOCK_AMPL %E", offset, amplitude);
	ibwrtbd(bd, msg, strlen(msg));
	if (ibcnt<5) /* power off returns count of 1 */
		return;
	sprintf(msg,"DATA_OFFSET %E; DATA_AMPL %E", offset, amplitude);
	ibwrtbd(bd, msg, strlen(msg));
	sprintf(msg,"DATA_INVERT OFF; ERROR_RATE OFF");
	ibwrtbd(bd, msg, strlen(msg));

	gpib_device=CSA907AR;
	sprintf(msg,"CLOCK_TERM GND; CLOCK_INPUT DIFF");
	ibwrtbd(bd, msg, strlen(msg));
	sprintf(msg,"DATA_TERM GND; DATA_INPUT DIFF; DATA_INVERT OFF");
	ibwrtbd(bd, msg, strlen(msg));
/*
	gpib_device=CSA907AT;
	do_one_test((float)1.0E+6,"OFF");
	do_one_test((float)1.0E+7,"OFF");
	do_one_test((float)1.0E+8,"OFF");
	do_one_test((float)2.0E+8,"OFF");
	do_one_test((float)4.0E+8,"OFF");
	do_one_test((float)7.0E+8,"OFF");
*/

	gpib_device=CSA907AR;
	sprintf(msg,"CLOCK_INPUT SINGLE; CLOCK_THRES %E", offset+amplitude/2);
	ibwrtbd(bd, msg, strlen(msg));
	sprintf(msg,"DATA_INPUT SINGLE; DATA_THRES %E", offset+amplitude/2);
	ibwrtbd(bd, msg, strlen(msg));

	gpib_device=CSA907AT;
	do_one_test((float)1.0E+6,"AUTO");
	do_one_test((float)1.0E+7,"AUTO");
	do_one_test((float)1.0E+8,"AUTO");
	do_one_test((float)2.0E+8,"AUTO");
	do_one_test((float)4.0E+8,"AUTO");
	do_one_test((float)7.0E+8,"AUTO");

	gpib_device=CSA907AR;
	ibwrtbd(bd, "HEADER ON",9);
}

/*****************************************************************************
 *****************************************************************************/

void init_colors(void)
{
	if ( *(char far *)0x00400049 == 7 )
	{
		f_colorbfr(2,0,14);
		f_colorerr(2,14);
		f_colormsg(2,0,14);
		f_colorstg(2,0,14);
		f_coloredln(2,0,15,0,15);
	}

	dso_init();                        /* initialize dso() address */
}


/*****************************************************************************
 *****************************************************************************/

void main(argc,argv)
    int argc;
    char **argv;
    {
	register char **p;
	int    month, day, year;
	int    hours, minutes, seconds;
	int    i, bd, count=0, savrow, savcol, *ptr_area;
	char msg[100];
	FILE   *ptr;
	char text[80];


	/* View data following 'drive:\dir\filename.EXE'  */
	p = argv+1;
	strcpy(text,*p);
	if (strlen(text)>=2)
	{       if (strtest(text,"T")==0 || strtest(text,"t")==0 )
		{       /* Delay time after Power_SRQ ( or last test complete */
			warmup=atoi(&text[1]);
			argv++;
		}
	}
	p = argv+1;
	strcpy(text,*p);
	if (strlen(text)>=2)
	{
		if (strtest(text,"SRQ")>=0 || strtest(text,"srq")>=0 )
		{       /* 1 or 0; wait for PowerSRQ ? True/False */
			power_SRQ=atoi(&text[3]); 
			argv++;
		}
	}
	p = argv+1;
	strcpy(text,*p);
	if (strlen(text)>2)
	{       if (strtest(text,"BOTH")>=0 || strtest(text,"both")>=0 )
			TWO_PAIRS=1;
		else
		{
			printf("\n\tUnknown parameter '%s'\n",text);
			exit(0);
		}
	}

	/* The time function returns the number of seconds elapsed since
	   00:00:00 Greenwich mean time (GMT), January 1, 1970, according to the
	   system clock.  The system time is first adjusted according to the
	   timezone system variable. */
	time(&ltime);

	/* Set message output colors */
	init_colors();

	rdcrsr(&savrow,&savcol);      /* save DOS cursor position */
	mvcrsr(0,0);                  /* remove cursor from the CRT */

	/* Save the DOS screen before erase it */
	if ( (ptr_area=(int *)malloc(4000)) == NULL)
	{
		f_dsperr("Error, low memory - check CONFIG.SYS / AUTOEXEC.BAT (1.0)",57,10,10);
		exit(-1);
	}
	dsasave((char *)ptr_area,2000,1,1);
	clrscn();

	for (i=0; i<6; i++)
	{
		memset(input[i],32,80);
		memset(output[i],32,80);
	}
	ftextbox(1,1,9,38+15,color);
	ftextbox(1,38+15+1,9,80-(38+15),color);

	/* Check communications between the PC and the CSA907A's */
	CSA907AR=14; CSA907AT=15;
	bd=find_both_devices();
	if (TWO_PAIRS==1)
	{
		CSA907AR=16; CSA907AT=17;
		bd=find_both_devices();
	}

	display_start_time(&hours, &minutes, &seconds, &month, &day, &year);
	display_elapsed_time(ltime,1);
	/* draw box for the 'CURRENT TIME' */
	ftextbox(13+2,3,4,35,color);
	if (FILE_IO==1)
	{       /* erase any old data */
		ptr=fopen(datafile, "w");
		fclose(ptr);
	}
	do
	{
		CSA907AR=14; CSA907AT=15;
		if (power_SRQ==1)
			wait_for_power_SRQ(bd);
		if (TWO_PAIRS==1)
		{
			CSA907AR=16; CSA907AT=17;
			if (power_SRQ==1)
				wait_for_power_SRQ(bd);
		}
		sprintf(msg,"Waiting for %d minute warmup ...", warmup);
		display_current_task(msg, color);
		wait_minutes(warmup);
		/* run freq tests at : 1V Ampl, 0V offset,
				       1V Ampl, -1V offset,
				       2V Ampl, -1V offset             */
		CSA907AR=14; CSA907AT=15;
		do_all_tests((float)0.0, (float)1.00);
		do_all_tests((float)-1.0, (float)1.00);
		do_all_tests((float)-1.0, (float)2.00);
		if (TWO_PAIRS==1)
		{
			CSA907AR=16; CSA907AT=17;
			do_all_tests((float)0.0, (float)1.00);
			do_all_tests((float)-1.0, (float)1.00);
			do_all_tests((float)-1.0, (float)2.00);
		}
		display_elapsed_time(ltime,0);
		/* update the counter that hold the completed tests */
		count++;
		display_total_test_count(count);
	} while (nxtchr()!=ALTF1);

	/* Restore the DOS screen */
	dsarest((char *)ptr_area,2000,1,1);
	free(ptr_area);
	/* Put the DOS cursor back up */
	mvcrsr(savrow,1);
}

/*****************************************************************************
 *****************************************************************************/

